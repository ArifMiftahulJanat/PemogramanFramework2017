<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		$data = array(
				'nama' => "Arif Miftahul Janat",
				'ttl' => "Simpang Agung, 25 Maret 1996",
				'nim'  => "1541180150",
				'alamat' => "Lampung",
				'no_telp' => '085755214080',
				'hobi' => 'Futsal, Badminton, Renang, Dll',

			);
		$this->load->view('About',$data);
	}

}

/* End of file About.php */
/* Location: ./application/controllers/About.php */